jQuery.noConflict(); // jQuery is now removed from the $ namespace
                     // to use the $ shorthand, use (function($){ ... })(jQuery);
                     // and for the onload handler: jQuery(function($){ ... });