Testing in Trac
===============

So, you'd like to make sure Trac works in your configuration.
Excellent.  Here's what you need to know.

.. toctree::
   :maxdepth: 2

   testing-intro
   testing-core
   testing-environment
   testing-database
   testing-plugins

.. todo :: write more, with testing-specific steps.
