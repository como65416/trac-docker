:mod:`trac.wiki.admin`
======================

.. automodule :: trac.wiki.admin
   :members:

