:mod:`trac.config`
==================

.. automodule :: trac.config
   :members:

.. autoclass :: UnicodeConfigParser
   :members:

.. autoclass :: Section
   :members:

.. autofunction :: get_configinfo


Components
----------

.. autoclass :: ConfigurationAdmin
