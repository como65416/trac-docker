:mod:`trac.admin.console`
=========================

.. automodule :: trac.admin.console
   :members:

