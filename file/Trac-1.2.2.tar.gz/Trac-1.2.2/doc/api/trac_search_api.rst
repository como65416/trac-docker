:mod:`trac.search.api`
======================

.. automodule :: trac.search.api
   :members:

