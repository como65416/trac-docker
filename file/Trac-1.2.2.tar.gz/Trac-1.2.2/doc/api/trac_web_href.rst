:mod:`trac.web.href` -- Creation of URLs
========================================

.. module :: trac.web.href

This module mainly proposes the following class:

.. autoclass :: trac.web.href.Href
   :members:
