:mod:`trac.perm`
================

.. automodule :: trac.perm
   :members:

Components
----------

.. autoclass :: DefaultPermissionGroupProvider
   :members:

.. autoclass :: DefaultPermissionPolicy
   :members:

.. autoclass :: DefaultPermissionStore
   :members:

.. autoclass :: PermissionAdmin
   :members:

Miscellaneous
-------------

.. autoclass :: PermissionCache
   :members:

