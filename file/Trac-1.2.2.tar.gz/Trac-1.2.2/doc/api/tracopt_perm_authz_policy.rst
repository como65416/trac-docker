:mod:`tracopt.perm.authz_policy`
================================

.. automodule :: tracopt.perm.authz_policy
   :members:

