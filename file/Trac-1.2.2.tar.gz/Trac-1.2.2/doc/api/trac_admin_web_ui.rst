:mod:`trac.admin.web_ui`
========================

.. automodule :: trac.admin.web_ui
   :members:

