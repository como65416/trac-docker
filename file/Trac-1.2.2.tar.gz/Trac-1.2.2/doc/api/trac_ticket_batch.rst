:mod:`trac.ticket.batch`
========================

.. automodule :: trac.ticket.batch
   :members:

