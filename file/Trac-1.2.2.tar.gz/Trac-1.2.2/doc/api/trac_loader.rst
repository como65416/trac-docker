:mod:`trac.loader`
==================

.. automodule :: trac.loader
   :members:

.. autofunction :: get_plugin_info
.. autofunction :: get_plugins_dir
.. autofunction :: load_eggs
.. autofunction :: load_py_files
.. autofunction :: match_plugins_to_frames

