========
Glossary
========

.. glossary::
   :sorted:

   VCS
      Version Control System, what you use for versioning your source code
